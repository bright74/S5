#include <stdio.h>

#define HAUTEUR 10
#define LARGEUR 15
#define NB_PIECES 2
#define HAUTEUR_MAX_DES_PIECES 4

typedef char Grille[HAUTEUR][LARGEUR];

struct SPiece {
	int hauteur;
	int largeur;
	char* forme [HAUTEUR_MAX_DES_PIECES];
};

typedef struct SPiece Piece;

void initialiseGrille (Grille g) {
	for (int j=0; j<HAUTEUR; j++) {
		for (int i=0;i<LARGEUR;i++){
			g[j][i] = ' ';
		}
	}
}

char lireCase (Grille g, int lig, int col){
	return g[lig][col];
}

void ecrireCase(Grille g, int lig, int col, char c) {
	g[lig][col]=c;
}

int hauteurPlat(Grille g, int premcol, int dercol){
	int hautmax=HAUTEUR;
	for ( int i = premcol; i <= dercol; i++ ){
		int trou = 0;
		for (int j=HAUTEUR-1; j>=0; j--){
			if (j<hautmax-1 && g[j][i]!=' ' && trou==1){
				hautmax = j+1;
			}
		}
	}
}

void afficheGrille (Grille g){
	for (int i=HAUTEUR-1; i>=0; i--){
		printf("%d ||",i);
		for (int j=0;j<LARGEUR;j++){
			printf("%c", lireCase(g, i, j));
		}
		printf("||\n");
	}
	printf("  |||||||||||||||||||\n");
	printf("    0         1    \n");
	printf("    012345678901234\n");
}
void genererPieces(Piece tabPiece[]) {

	tabPiece[0].hauteur = 2;
	tabPiece[0].largeur = 2;
	tabPiece[0].forme[1] = "@@";
	tabPiece[0].forme[0] = "@@";

	tabPiece[1].hauteur = 4;
	tabPiece[1].largeur = 1;
	tabPiece[1].forme[3] = "l";
	tabPiece[1].forme[2] = "l";
	tabPiece[1].forme[1] = "l";
	tabPiece[1].forme[0] = "l";
}

void affichePiece(Piece p) {
	int tmp = 0;
	for(int i=0; i<p.hauteur; i++) {
		printf("          %s\n", p.forme[i]);
	}

}

int main(){

	Grille g;
	Piece tabPiece[NB_PIECES];
	initialiseGrille(g);
	genererPieces(tabPiece);
	affichePiece(tabPiece[0]);
	afficheGrille(g);
		printf("lol\n");
	return 0;
}